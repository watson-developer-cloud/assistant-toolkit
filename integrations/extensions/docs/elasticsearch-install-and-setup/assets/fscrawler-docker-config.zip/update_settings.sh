#!/bin/sh

cd config/idx

sed -i '' "s~ES_INDEX_NAME~$ES_INDEX_NAME~g" _settings.yaml 
sed -i '' "s~ES_URL~$ES_URL~g" _settings.yaml 
sed -i '' "s~ES_USER~$ES_USER~g" _settings.yaml 
sed -i '' "s~ES_PASSWORD~$ES_PASSWORD~g" _settings.yaml 
sed -i '' "s~ES_PIPELINE_NAME~$ES_PIPELINE_NAME~g" _settings.yaml 